import './GraphImage.css'
function GraphImage(){
    return(
        <img id='Image-tag' src="https://titrias.com/files/2015/08/Untitled.png" alt="Comparison Graph Image"/>
    );
}

export default GraphImage;