import './header.css'
function Header(){
    return (
        <header>
            <h1>Sorting Visualizer</h1>
            <button>Toggle Mode</button>
        </header>
    );
}

export default Header